#!/usr/bin/env python3

import json
import sys
import webbrowser
import urllib.request
from pathlib import Path

class MuavesPortfolio:
    def __init__(self):
        self.base_api_url = "https://muaves-portfolio-api.onrender.com"
        
        self.endpoints = {
            "about": "/api/about",
            "links": "/api/links",
            "projects": "/api/projects",
            "stats": "/api/stats"
        }

    def _fetch_data(self, endpoint_key):
        url = self.base_api_url + self.endpoints[endpoint_key]
        try:
            with urllib.request.urlopen(url, timeout=10) as response:
                if response.status == 200:
                    return json.loads(response.read().decode('utf-8'))
                else:
                    print(f"Server Error ({response.status}) on {url}")
                    return None
        except Exception as e:
            print(f"Connection error: {e}")
            return None

    def show_help(self):
        print("\n" + "="*60)
        print("  Muaves Portfolio CLI - API Mode")
        print("="*60)
        print("\nAvailable Commands:")
        print("  muaves              Show this help message")
        print("  muaves -oA          Show About Me (from /api/about)")
        print("  muaves -oP          Show Projects (from /api/projects)")
        print("  muaves -oH          Show Help")
        print("  muaves -OW          Open website in browser")
        print("  muaves -H:l         Show and open links (from /api/links)")
        print("  muaves --version    Show version")
        print("\n" + "="*60 + "\n")

    def show_about(self):
        print("Connecting to https://muaves-portfolio-api.onrender.com/api/about...")
        print("Loading: api/about...")
        data = self._fetch_data("about")
        if data:
            print("\n" + "="*60)
            print("  ABOUT ME")
            print("="*60)
            content = data.get('about', data) if isinstance(data, dict) else data
            print(f"\n{content}\n")
            print("="*60 + "\n")

    def show_projects(self):
        print("Connecting to https://muaves-portfolio-api.onrender.com/api/projects...")
        print("Loading: api/projects...")
        projects = self._fetch_data("projects")
        if projects:
            print("\n" + "="*60)
            print("  MY PROJECTS")
            print("="*60 + "\n")
            
            for i, p in enumerate(projects, 1):
                print(f"[{i}] {p.get('name', 'N/A')}")
                print(f"    {p.get('description', '')}")
                print(f"    Tech: {p.get('tech', '')} | Status: {p.get('status', '')}")
                print()
            print("="*60 + "\n")

    def show_links(self):
        print("Connecting to https://muaves-portfolio-api.onrender.com/api/links...")
        print("Loading: api/links...")
        links = self._fetch_data("links")
        if links:
            print("\n" + "="*60)
            print("  MY LINKS")
            print("="*60 + "\n")
            
            for i, link in enumerate(links, 1):
                print(f"  {i}. {link.get('name')} -> {link.get('url')}")
            
            print("\n" + "="*60)
            choice = input("\nEnter number to open (or Enter to cancel): ").strip()
            if choice.isdigit():
                idx = int(choice) - 1
                if 0 <= idx < len(links):
                    webbrowser.open(links[idx]['url'])

    def show_version(self):
        print("\nMuaves Portfolio CLI v1.0.6 (API Driven)\n")

    def handle_command(self, args):
        if len(args) == 0 or args[0].lower() == '-oh':
            self.show_help()
            return
        
        cmd = args[0].lower()
        if cmd == '-oa': self.show_about()
        elif cmd == '-op': self.show_projects()
        elif cmd == '-h:l': self.show_links()
        elif cmd == '-ow': webbrowser.open("https://muaves.github.io")
        elif cmd in ['--version', '--v']: self.show_version()
        else:
            print(f"Unknown command: {args[0]}")

def main():
    portfolio = MuavesPortfolio()
    portfolio.handle_command(sys.argv[1:])

if __name__ == "__main__":
    main()