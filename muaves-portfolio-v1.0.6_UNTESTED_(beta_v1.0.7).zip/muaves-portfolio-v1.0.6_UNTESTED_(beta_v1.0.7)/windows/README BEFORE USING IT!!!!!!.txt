Hi, so the windows version might be broken because I'm not using windows so I can't test it!

Please contact through discord for bug report!
https://dc.muaves.com
